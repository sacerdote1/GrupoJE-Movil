[app]
title = Grupo JE Móvil
package.name = grupoje
package.domain = com.grupoje
source.dir = .
source.include_exts = py,png,jpg,jpeg,json,ttf
version = 1.0.0
requirements = python3,kivy==2.3.1,certifi
orientation = portrait
fullscreen = 0
icon.filename = assets/logo.png
presplash.filename = assets/logo.png
android.permissions = INTERNET
android.api = 36
android.minapi = 24
android.ndk = 28c
android.accept_sdk_license = True
android.archs = arm64-v8a, armeabi-v7a
android.allow_backup = False

[buildozer]
log_level = 2
warn_on_root = 1
