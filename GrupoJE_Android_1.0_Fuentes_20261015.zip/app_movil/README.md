# Grupo JE Móvil

## Aplicación Android preparada

La aplicación Android real está en `app_movil/android`. Está desarrollada con
Kivy, consume el catálogo y las fotografías mediante la API local y **no**
incluye una copia de SQLite, contraseñas ni datos administrativos. Para probarla
en Windows use `probar_android_windows.cmd`; para permitir que un teléfono la
consulte en la misma red use `iniciar_api_android.cmd`.

La compilación del APK está descrita en `android/README_ANDROID.md`. El proyecto
incluye `buildozer.spec` y el workflow `.github/workflows/android-apk.yml`, de
modo que puede generarse con Buildozer en Linux o desde GitHub Actions sin
modificar el código.

La vista Tkinter anterior se conserva como referencia visual de escritorio.

Esta carpeta contiene la primera versión visual de la aplicación móvil de
Grupo JE. Su enfoque principal son los **clientes y compradores**: permite
explorar el catálogo, ver fotografías, guardar favoritos, comparar vehículos,
simular cuotas, consultar ofertas y planificar visitas sin iniciar sesión.

Empleados y gerentes disponen de un área interna secundaria. Esta utiliza las
cuentas, roles y permisos reales del sistema central; las ventas, el inventario
y las reservas asistidas no se cargan ni se muestran a visitantes.

## Ejecutar la vista previa

La vista visual puede abrirse ahora mismo, sin instalaciones adicionales:

```powershell
python app_movil\vista_previa_tk.py
```

`main.py` abre esta misma versión actual; se mantiene como punto de entrada
para no tener un segundo prototipo con datos ficticios:

```powershell
python app_movil\main.py
```

La compilación nativa utiliza la nueva carpeta `android`; esta vista Tkinter no
se empaqueta como APK.

La versión actual incluye una bienvenida 2D real creada con `Tkinter.Canvas`
(faros, carrocería deportiva, ruedas, reflejos, líneas de velocidad y
partículas que se desplazan con `after()`, sin fotografías estáticas ni
modelos 3D), las pantallas
visuales de Inicio, Vehículos, Detalle, Galería, Favoritos, Comparador,
Simulador de cuota, Ofertas, Centro de actividad, Reservas, Ventas con
comprobante, Inventario y Perfil. La navegación pública prioriza Inicio,
Vehículos, Favoritos, Agenda y Perfil. El catálogo permite filtros combinables y orden real
por precio, descuento, año o marca; Inicio conserva hasta cinco fichas vistas recientemente
en el dispositivo, sin modificar vehículos ni datos empresariales. También
incluye un explorador por presupuesto y un directorio de sucursales con la
disponibilidad registrada en cada ubicación. La agenda móvil permite guardar
recordatorios personales de visita y copiar fichas comerciales; esas acciones
son locales y no crean citas, reservas ni ventas en Grupo JE. La vista
incluye además una guía «Cómo comprar»: la app ayuda a elegir y planificar,
pero el pago y la venta se confirman con personal autorizado en el sistema de
escritorio. Después, Factura puede entregar un expediente ZIP con la factura,
la ficha técnica, el resumen de entrega, la constancia de garantía registrada
y un manifiesto comercial con huellas SHA-256, ya sea
mediante exportación o como adjunto del correo de factura cuando SMTP esté
configurado.
La vista
previa de Tkinter lee el catálogo real de vehículos, fotos, precio oficial,
estado y sucursal desde SQLite en modo de solo lectura. Los datos internos de
reservas, ventas e inventario se cargan solamente después de autenticar al
personal. Con el permiso correspondiente, una reserva asistida se realiza
mediante `reservas_service.py`.

Una copia independiente puede incluir `conexion_sistema_movil.json` con una
`ruta_proyecto` relativa o absoluta. Cuando esa instalación está disponible,
la vista consulta sus datos reales; si no, usa con seguridad la copia local de
la base y de las imágenes incluida en la carpeta móvil.

En escritorio, la vista se centra dentro de un marco móvil con ancho máximo:
no se estira al maximizar la ventana. El contenido conserva desplazamiento
vertical y las fotografías mantienen su proporción.

## Puente local para Android

`api_consulta.py` ofrece catálogo, sucursales y fotografías mediante HTTP de
solo lectura. De forma predeterminada se limita al propio equipo (`127.0.0.1`):

```powershell
python app_movil\api_consulta.py
```

Para Android se inicia con `--lan --solo-publico`. La API rechaza POST, PUT y
DELETE, y en este modo también bloquea ventas, reservas e inventario con 403.
Estas operaciones siguen en el sistema de escritorio.

## Límites intencionales de esta primera versión

- El catálogo público usa `mode=ro`; ventas, inventario y reservas solo se
  consultan dentro del área interna autenticada.
- Las únicas operaciones móviles habilitadas son **crear o cancelar una
  reserva**, tras autenticación, permiso de Vehículos y confirmación explícita.
  Ambas usan las transacciones centrales ya validadas.
- No crea ventas, clientes ni ajusta inventario.
- No sustituye ni altera la aplicación Tkinter de escritorio.
- Favoritos y el comparador de dos vehículos son preferencias locales de la
  vista móvil; no cambian vehículos, precios ni inventario de Grupo JE.
- La API HTTP continúa siendo solo de lectura; las operaciones móviles a través
  de red requerirán autenticación por API antes de habilitarse.
