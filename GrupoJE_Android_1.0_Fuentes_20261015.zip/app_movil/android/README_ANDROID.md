# Grupo JE Móvil para Android

Esta carpeta contiene la aplicación Kivy preparada para Android. El APK no
incluye SQLite, contraseñas, usuarios ni datos internos. Consulta únicamente
el catálogo público que sirve `app_movil/api_consulta.py`.

## Probar en Windows

Desde la carpeta del proyecto:

```powershell
$env:KIVY_HOME="$PWD\.kivy_runtime"
python app_movil\android\main.py
```

En otra terminal inicia la API local:

```powershell
python app_movil\api_consulta.py --puerto 8765
```

Para un teléfono real ejecuta `app_movil\iniciar_api_android.cmd`. Windows
puede solicitar autorización para la red privada. En la pantalla Conexión de
la app escribe la IPv4 de la PC, por ejemplo:

```text
http://192.168.1.10:8765
```

El teléfono y la PC deben estar en la misma red. `10.0.2.2` funciona solamente
desde el emulador oficial de Android.

## Crear el APK

Buildozer necesita Linux. Este equipo Windows no tiene WSL, Docker, Java ni el
SDK de Android, por lo que el APK debe compilarse mediante una de estas rutas:

1. Subir el proyecto a GitHub y ejecutar el workflow `Android APK` incluido.
   Al finalizar se descarga el artefacto `GrupoJE-Android` desde Actions.
2. Compilar en Linux/WSL desde `app_movil/android`:

```bash
python3 -m pip install buildozer cython
buildozer android debug
```

El resultado queda en `app_movil/android/bin/`.

## Seguridad

- El modo `--solo-publico` entrega únicamente salud, catálogo, fotografías y
  sucursales activas.
- Ventas, inventario y reservas internas responden `403`.
- El APK no contiene el token administrativo.
- Las ventas y pagos continúan realizándose en el sistema de escritorio.
- Para operar fuera de la red local se requiere publicar la API detrás de
  HTTPS; no se debe abrir directamente el puerto de SQLite ni copiar la base al
  teléfono.
