"""Grupo JE Móvil para Android.

Cliente Kivy del catálogo público. Nunca abre SQLite ni contiene credenciales
del sistema empresarial.
"""
from __future__ import annotations

import json
import os
import sys
from pathlib import Path
from urllib.parse import urljoin

# Windows administrado puede bloquear ~/.kivy. Esta ruta solo se usa durante
# la vista previa; Android usa el almacenamiento privado de la aplicación.
if sys.platform == "win32":
    os.environ.setdefault("KIVY_HOME", str(Path(__file__).resolve().parent / ".kivy_runtime"))

from kivy.animation import Animation
from kivy.app import App
from kivy.clock import Clock
from kivy.core.window import Window
from kivy.graphics import Color, Ellipse, Line, RoundedRectangle
from kivy.metrics import dp, sp
from kivy.network.urlrequest import UrlRequest
from kivy.properties import ListProperty, NumericProperty, StringProperty
from kivy.uix.image import AsyncImage
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.uix.gridlayout import GridLayout
from kivy.uix.label import Label
from kivy.uix.screenmanager import FadeTransition, Screen, ScreenManager
from kivy.uix.scrollview import ScrollView
from kivy.uix.textinput import TextInput
from kivy.uix.widget import Widget


NAVY = (0.025, 0.09, 0.19, 1)
BLUE = (0.04, 0.36, 0.82, 1)
BLUE_LIGHT = (0.86, 0.92, 1, 1)
SURFACE = (0.96, 0.975, 1, 1)
WHITE = (1, 1, 1, 1)
TEXT = (0.06, 0.12, 0.20, 1)
MUTED = (0.34, 0.43, 0.55, 1)
GREEN = (0.03, 0.58, 0.32, 1)
AMBER = (0.92, 0.53, 0.08, 1)


def money(value) -> str:
    try:
        return f"US$ {float(value or 0):,.2f}"
    except (TypeError, ValueError):
        return "US$ 0.00"


class RoundedButton(Button):
    color_normal = ListProperty(BLUE)
    color_down = ListProperty((0.02, 0.25, 0.62, 1))

    def __init__(self, **kwargs):
        kwargs.setdefault("background_normal", "")
        kwargs.setdefault("background_down", "")
        kwargs.setdefault("background_color", (0, 0, 0, 0))
        kwargs.setdefault("color", WHITE)
        kwargs.setdefault("font_size", sp(14))
        kwargs.setdefault("bold", True)
        kwargs.setdefault("size_hint_y", None)
        kwargs.setdefault("height", dp(48))
        super().__init__(**kwargs)
        with self.canvas.before:
            self._button_color = Color(*self.color_normal)
            self._button_shape = RoundedRectangle(pos=self.pos, size=self.size, radius=[dp(14)])
        self.bind(pos=self._sync_canvas, size=self._sync_canvas, state=self._sync_canvas)

    def _sync_canvas(self, *_args):
        self._button_shape.pos = self.pos
        self._button_shape.size = self.size
        self._button_color.rgba = self.color_down if self.state == "down" else self.color_normal


class Card(BoxLayout):
    background = ListProperty(WHITE)

    def __init__(self, **kwargs):
        kwargs.setdefault("padding", dp(14))
        kwargs.setdefault("spacing", dp(10))
        super().__init__(**kwargs)
        with self.canvas.before:
            self._shadow_color = Color(0.08, 0.17, 0.30, 0.08)
            self._shadow = RoundedRectangle(pos=(self.x, self.y - dp(2)), size=self.size, radius=[dp(16)])
            self._bg_color = Color(*self.background)
            self._bg = RoundedRectangle(pos=self.pos, size=self.size, radius=[dp(16)])
        self.bind(pos=self._sync_canvas, size=self._sync_canvas, background=self._sync_canvas)

    def _sync_canvas(self, *_args):
        self._shadow.pos = (self.x, self.y - dp(2))
        self._shadow.size = self.size
        self._bg.pos = self.pos
        self._bg.size = self.size
        self._bg_color.rgba = self.background


def text_label(text="", size=14, color=TEXT, bold=False, **kwargs):
    label = Label(
        text=text,
        color=color,
        font_size=sp(size),
        bold=bold,
        halign=kwargs.pop("halign", "left"),
        valign=kwargs.pop("valign", "middle"),
        **kwargs,
    )
    label.bind(size=lambda widget, _value: setattr(widget, "text_size", (widget.width, None)))
    return label


class CarWidget(Widget):
    car_x = NumericProperty(-320)

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.bind(pos=self._draw, size=self._draw, car_x=self._draw)

    def _draw(self, *_args):
        self.canvas.clear()
        x = self.x + self.car_x
        y = self.y + self.height * 0.35
        scale = min(self.width / 440, self.height / 220)
        with self.canvas:
            Color(0.05, 0.48, 1, 0.22)
            for offset in (0, 55, 110):
                Line(points=[x - dp(190 + offset), y + dp(32), x - dp(35 + offset), y + dp(32)], width=1.2)
            Color(0.03, 0.29, 0.72, 1)
            RoundedRectangle(pos=(x - dp(135) * scale, y), size=(dp(280) * scale, dp(67) * scale), radius=[dp(25)])
            Color(0.02, 0.10, 0.22, 1)
            RoundedRectangle(pos=(x - dp(55) * scale, y + dp(46) * scale), size=(dp(125) * scale, dp(55) * scale), radius=[dp(23)])
            Color(0.20, 0.66, 1, 1)
            Line(points=[x - dp(125) * scale, y + dp(35) * scale, x + dp(135) * scale, y + dp(35) * scale], width=2)
            Color(0.01, 0.025, 0.06, 1)
            for wheel_x in (-82, 86):
                Ellipse(pos=(x + dp(wheel_x - 24) * scale, y - dp(22) * scale), size=(dp(48) * scale, dp(48) * scale))
            Color(0.70, 0.90, 1, 1)
            Ellipse(pos=(x + dp(112) * scale, y + dp(24) * scale), size=(dp(30) * scale, dp(16) * scale))
            Color(0.08, 0.55, 1, 0.20)
            Ellipse(pos=(x + dp(120) * scale, y - dp(5) * scale), size=(dp(120) * scale, dp(80) * scale))


class SplashScreen(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        root = BoxLayout(orientation="vertical", padding=dp(24), spacing=dp(10))
        with root.canvas.before:
            Color(*NAVY)
            self._bg = RoundedRectangle(pos=root.pos, size=root.size)
        root.bind(pos=lambda *_: setattr(self._bg, "pos", root.pos), size=lambda *_: setattr(self._bg, "size", root.size))
        root.add_widget(Widget(size_hint_y=.15))
        title = text_label("GRUPO JE", 34, WHITE, True, size_hint_y=None, height=dp(55), halign="center")
        subtitle = text_label("TU PRÓXIMO VEHÍCULO COMIENZA AQUÍ", 12, (0.52, 0.74, 1, 1), True, size_hint_y=None, height=dp(35), halign="center")
        root.add_widget(title)
        root.add_widget(subtitle)
        self.car = CarWidget(size_hint_y=.42)
        root.add_widget(self.car)
        self.status = text_label("Conectando con el catálogo...", 11, (0.67, 0.78, 0.92, 1), False, size_hint_y=None, height=dp(30), halign="center")
        root.add_widget(self.status)
        skip = RoundedButton(text="ENTRAR AL CATÁLOGO", size_hint_x=.8, pos_hint={"center_x": .5})
        skip.bind(on_release=lambda *_: App.get_running_app().go("inicio"))
        root.add_widget(skip)
        root.add_widget(Widget(size_hint_y=.10))
        self.add_widget(root)

    def on_enter(self):
        self.car.car_x = -320
        Animation(car_x=210, duration=2.3, transition="out_cubic").start(self.car)
        Clock.schedule_once(lambda _dt: App.get_running_app().go("inicio"), 4.2)


class MobileScreen(Screen):
    title = StringProperty("GRUPO JE")
    subtitle = StringProperty("")

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.root_layout = BoxLayout(orientation="vertical")
        self.header = BoxLayout(orientation="horizontal", size_hint_y=None, height=dp(82), padding=[dp(16), dp(10)], spacing=dp(10))
        with self.header.canvas.before:
            Color(*NAVY)
            self._header_bg = RoundedRectangle(pos=self.header.pos, size=self.header.size)
        self.header.bind(pos=lambda *_: setattr(self._header_bg, "pos", self.header.pos), size=lambda *_: setattr(self._header_bg, "size", self.header.size))
        brand = BoxLayout(orientation="vertical")
        self.title_label = text_label(self.title, 19, WHITE, True)
        self.subtitle_label = text_label(self.subtitle, 9, (0.51, 0.72, 1, 1), True)
        brand.add_widget(self.title_label); brand.add_widget(self.subtitle_label)
        self.connection = text_label("EN LÍNEA", 9, (0.35, 0.85, 0.61, 1), True, size_hint_x=.30, halign="right")
        self.header.add_widget(brand); self.header.add_widget(self.connection)
        self.root_layout.add_widget(self.header)
        self.body = BoxLayout(orientation="vertical")
        self.root_layout.add_widget(self.body)
        self.nav = self._navigation()
        self.root_layout.add_widget(self.nav)
        self.add_widget(self.root_layout)

    def _navigation(self):
        nav = BoxLayout(size_hint_y=None, height=dp(66), padding=dp(4), spacing=dp(3))
        with nav.canvas.before:
            Color(*WHITE)
            shape = RoundedRectangle(pos=nav.pos, size=nav.size)
        nav.bind(pos=lambda *_: setattr(shape, "pos", nav.pos), size=lambda *_: setattr(shape, "size", nav.size))
        for label, target in (("Inicio", "inicio"), ("Vehículos", "catalogo"), ("Favoritos", "favoritos"), ("Conexión", "conexion")):
            button = Button(text=label, background_normal="", background_color=(0, 0, 0, 0), color=BLUE if target == self.name else MUTED, font_size=sp(11))
            button.bind(on_release=lambda _button, screen=target: App.get_running_app().go(screen))
            nav.add_widget(button)
        return nav

    def set_status(self, online: bool):
        self.connection.text = "EN LÍNEA" if online else "SIN CONEXIÓN"
        self.connection.color = (0.35, 0.85, 0.61, 1) if online else (1, .55, .55, 1)


def scroll_content(padding=16, spacing=12):
    scroll = ScrollView(do_scroll_x=False)
    content = GridLayout(cols=1, spacing=dp(spacing), padding=dp(padding), size_hint_y=None)
    content.bind(minimum_height=content.setter("height"))
    scroll.add_widget(content)
    return scroll, content


class HomeScreen(MobileScreen):
    def __init__(self, **kwargs):
        kwargs.update(title="INICIO", subtitle="EXPERIENCIA PARA CLIENTES")
        super().__init__(**kwargs)
        scroll, content = scroll_content()
        hero = Card(orientation="vertical", size_hint_y=None, height=dp(180), background=NAVY)
        hero.add_widget(text_label("Encuentra tu próximo vehículo", 22, WHITE, True, size_hint_y=.45))
        hero.add_widget(text_label("Catálogo real de Grupo JE conectado de forma segura.", 11, (0.72, .84, 1, 1), False, size_hint_y=.25))
        button = RoundedButton(text="EXPLORAR CATÁLOGO")
        button.bind(on_release=lambda *_: App.get_running_app().go("catalogo"))
        hero.add_widget(button); content.add_widget(hero)
        self.summary = text_label("Conecta la app para cargar datos reales.", 14, TEXT, True, size_hint_y=None, height=dp(70))
        content.add_widget(self.summary)
        for title, description, target in (
            ("Favoritos", "Guarda vehículos en este teléfono.", "favoritos"),
            ("Cómo comprar", "Conoce el proceso de reserva, venta, factura y expediente digital.", "comprar"),
            ("Configurar conexión", "Indica la dirección de la PC donde se ejecuta Grupo JE.", "conexion"),
        ):
            card = Card(orientation="vertical", size_hint_y=None, height=dp(125))
            card.add_widget(text_label(title, 17, TEXT, True))
            card.add_widget(text_label(description, 10, MUTED))
            action = RoundedButton(text="ABRIR", size_hint_y=None, height=dp(38))
            action.bind(on_release=lambda _button, screen=target: App.get_running_app().go(screen))
            card.add_widget(action); content.add_widget(card)
        self.body.add_widget(scroll)

    def on_pre_enter(self):
        app = App.get_running_app()
        available = sum(str(v.get("estado")) == "Disponible" for v in app.catalog)
        self.summary.text = f"{len(app.catalog)} vehículos en catálogo · {available} disponibles" if app.catalog else "Sin catálogo cargado. Revisa Conexión."
        self.set_status(app.online)


class CatalogScreen(MobileScreen):
    def __init__(self, **kwargs):
        kwargs.update(title="VEHÍCULOS", subtitle="CATÁLOGO REAL · GRUPO JE")
        super().__init__(**kwargs)
        search_row = BoxLayout(size_hint_y=None, height=dp(58), padding=[dp(12), dp(8)], spacing=dp(8))
        self.search = TextInput(hint_text="Marca, modelo, año o código", multiline=False, font_size=sp(14), padding=[dp(12), dp(12)])
        self.search.bind(text=lambda *_: self.render())
        refresh = RoundedButton(text="ACTUALIZAR", size_hint_x=None, width=dp(88), height=dp(42), font_size=sp(10))
        refresh.bind(on_release=lambda *_: App.get_running_app().load_catalog())
        search_row.add_widget(self.search); search_row.add_widget(refresh)
        self.body.add_widget(search_row)
        self.scroll, self.listing = scroll_content(12, 10)
        self.body.add_widget(self.scroll)

    def render(self):
        self.listing.clear_widgets()
        app = App.get_running_app()
        query = self.search.text.strip().casefold()
        vehicles = [v for v in app.catalog if not query or query in " ".join(str(v.get(k) or "") for k in ("codigo", "marca", "modelo", "version", "anio", "estado")).casefold()]
        if not vehicles:
            self.listing.add_widget(text_label("No hay vehículos que coincidan con la búsqueda.", 12, MUTED, size_hint_y=None, height=dp(90), halign="center"))
            return
        for vehicle in vehicles:
            card = Card(orientation="horizontal", size_hint_y=None, height=dp(155), spacing=dp(12))
            source = app.absolute_url(vehicle.get("foto_url"))
            image = AsyncImage(source=source or "", fit_mode="contain", size_hint_x=.38)
            card.add_widget(image)
            info = BoxLayout(orientation="vertical", spacing=dp(3))
            name = " ".join(str(vehicle.get(k) or "") for k in ("marca", "modelo", "version", "anio")).strip()
            info.add_widget(text_label(name or "Vehículo", 16, TEXT, True, size_hint_y=.35))
            info.add_widget(text_label(f"{vehicle.get('codigo') or 'Sin código'} · {vehicle.get('estado') or 'Sin estado'}", 10, GREEN if vehicle.get("estado") == "Disponible" else AMBER, True, size_hint_y=.18))
            price = float(vehicle.get("precio_venta") or 0) * (1 - float(vehicle.get("descuento") or 0) / 100)
            info.add_widget(text_label(money(price), 14, BLUE, True, size_hint_y=.22))
            view = RoundedButton(text="VER DETALLE", height=dp(36))
            view.bind(on_release=lambda _button, item=vehicle: app.open_vehicle(item))
            info.add_widget(view); card.add_widget(info); self.listing.add_widget(card)

    def on_pre_enter(self):
        self.set_status(App.get_running_app().online)
        self.render()


class DetailScreen(MobileScreen):
    def __init__(self, **kwargs):
        kwargs.update(title="DETALLE", subtitle="INFORMACIÓN DEL VEHÍCULO")
        super().__init__(**kwargs)

    def on_pre_enter(self):
        self.body.clear_widgets()
        app = App.get_running_app(); vehicle = app.selected_vehicle or {}
        scroll, content = scroll_content()
        image = AsyncImage(source=app.absolute_url(vehicle.get("foto_url")) or "", size_hint_y=None, height=dp(240), fit_mode="contain")
        content.add_widget(image)
        name = " ".join(str(vehicle.get(k) or "") for k in ("marca", "modelo", "version", "anio")).strip()
        content.add_widget(text_label(name or "Vehículo", 23, TEXT, True, size_hint_y=None, height=dp(60)))
        price = float(vehicle.get("precio_venta") or 0) * (1 - float(vehicle.get("descuento") or 0) / 100)
        content.add_widget(text_label(f"{money(price)} · {vehicle.get('estado') or 'Sin estado'}", 16, BLUE, True, size_hint_y=None, height=dp(42)))
        fields = (
            ("Código", vehicle.get("codigo")), ("Sucursal", vehicle.get("nombre_sucursal")),
            ("Condición", vehicle.get("condicion")), ("Kilometraje", f"{vehicle.get('kilometraje') or 0} km"),
            ("Transmisión", vehicle.get("transmision")), ("Combustible", vehicle.get("combustible")),
        )
        for label, value in fields:
            row = Card(orientation="horizontal", size_hint_y=None, height=dp(58), padding=dp(10))
            row.add_widget(text_label(label, 10, MUTED, True))
            row.add_widget(text_label(str(value or "No registrado"), 11, TEXT, False, halign="right"))
            content.add_widget(row)
        description = vehicle.get("descripcion") or "Sin descripción registrada."
        desc = Card(orientation="vertical", size_hint_y=None, height=dp(120))
        desc.add_widget(text_label("Descripción", 14, TEXT, True, size_hint_y=.3))
        desc.add_widget(text_label(description, 10, MUTED, size_hint_y=.7))
        content.add_widget(desc)
        favorite = RoundedButton(text="QUITAR DE FAVORITOS" if app.is_favorite(vehicle) else "GUARDAR EN FAVORITOS")
        favorite.bind(on_release=lambda *_: (app.toggle_favorite(vehicle), self.on_pre_enter()))
        content.add_widget(favorite)
        buy = RoundedButton(text="CÓMO COMPRAR", color_normal=(.12, .24, .40, 1))
        buy.bind(on_release=lambda *_: app.go("comprar")); content.add_widget(buy)
        self.body.add_widget(scroll); self.set_status(app.online)


class FavoritesScreen(CatalogScreen):
    def __init__(self, **kwargs):
        MobileScreen.__init__(self, name=kwargs.get("name", "favoritos"), title="FAVORITOS", subtitle="GUARDADOS EN ESTE TELÉFONO")
        self.scroll, self.listing = scroll_content(12, 10)
        self.body.add_widget(self.scroll)
        self.search = type("Search", (), {"text": ""})()

    def render(self):
        app = App.get_running_app()
        original = app.catalog
        app.catalog = [v for v in original if app.is_favorite(v)]
        CatalogScreen.render(self)
        app.catalog = original


class PurchaseScreen(MobileScreen):
    def __init__(self, **kwargs):
        kwargs.update(title="CÓMO COMPRAR", subtitle="PROCESO SEGURO")
        super().__init__(**kwargs)
        scroll, content = scroll_content()
        steps = (
            ("1. Explora", "Consulta vehículos, precios, fotografías y sucursal."),
            ("2. Visita", "Contacta la sucursal para inspeccionar el vehículo."),
            ("3. Reserva asistida", "Un empleado autorizado vincula la reserva con el cliente."),
            ("4. Compra", "El sistema central valida pago, inventario, cliente y estado del vehículo."),
            ("5. Documentos", "Recibes factura y expediente digital con ficha, entrega, garantía y manifiesto verificable."),
        )
        for title, description in steps:
            card = Card(orientation="vertical", size_hint_y=None, height=dp(115))
            card.add_widget(text_label(title, 16, TEXT, True))
            card.add_widget(text_label(description, 10, MUTED))
            content.add_widget(card)
        note = Card(orientation="vertical", size_hint_y=None, height=dp(130), background=(1, .95, .85, 1))
        note.add_widget(text_label("Importante", 14, AMBER, True))
        note.add_widget(text_label("La app no cobra ni sustituye documentos gubernamentales. La compra se confirma con personal autorizado.", 10, TEXT))
        content.add_widget(note); self.body.add_widget(scroll)


class ConnectionScreen(MobileScreen):
    def __init__(self, **kwargs):
        kwargs.update(title="CONEXIÓN", subtitle="SERVIDOR GRUPO JE")
        super().__init__(**kwargs)
        scroll, content = scroll_content()
        content.add_widget(text_label("Dirección de la PC", 17, TEXT, True, size_hint_y=None, height=dp(45)))
        self.url = TextInput(multiline=False, hint_text="http://192.168.1.10:8765", size_hint_y=None, height=dp(52), font_size=sp(14), padding=[dp(12), dp(13)])
        content.add_widget(self.url)
        content.add_widget(text_label("El teléfono y la PC deben estar en la misma red. En emulador Android usa http://10.0.2.2:8765.", 10, MUTED, size_hint_y=None, height=dp(72)))
        save = RoundedButton(text="GUARDAR Y PROBAR")
        save.bind(on_release=lambda *_: self.save_and_test()); content.add_widget(save)
        self.result = text_label("", 11, MUTED, size_hint_y=None, height=dp(75))
        content.add_widget(self.result)
        privacy = Card(orientation="vertical", size_hint_y=None, height=dp(150), background=BLUE_LIGHT)
        privacy.add_widget(text_label("Conexión pública segura", 14, BLUE, True))
        privacy.add_widget(text_label("La app recibe catálogo, fotos y sucursales. Ventas, inventario, usuarios, contraseñas y reservas internas no se exponen.", 10, TEXT))
        content.add_widget(privacy); self.body.add_widget(scroll)

    def on_pre_enter(self):
        self.url.text = App.get_running_app().base_url
        self.set_status(App.get_running_app().online)

    def save_and_test(self):
        value = self.url.text.strip().rstrip("/")
        if not value.startswith(("http://", "https://")):
            self.result.text = "La dirección debe comenzar con http:// o https://"
            return
        app = App.get_running_app(); app.base_url = value; app.save_config()
        self.result.text = "Probando conexión..."
        app.load_catalog(on_done=lambda ok, message: setattr(self.result, "text", message))


class GrupoJEMobileApp(App):
    catalog = ListProperty([])
    # 10.0.2.2 es la dirección especial del host desde el emulador Android.
    # En la vista previa de Windows se usa localhost. En un teléfono real el
    # usuario indica una vez la IP LAN de la PC desde la pantalla Conexión.
    base_url = StringProperty(
        "http://127.0.0.1:8765" if sys.platform == "win32" else "http://10.0.2.2:8765"
    )

    def build(self):
        self.title = "Grupo JE Móvil"
        if sys.platform == "win32":
            Window.size = (420, 780)
        Window.clearcolor = SURFACE
        self.online = False
        self.selected_vehicle = None
        self.favorites = set()
        self._load_local_state()
        manager = ScreenManager(transition=FadeTransition(duration=.18))
        for screen in (
            SplashScreen(name="splash"), HomeScreen(name="inicio"), CatalogScreen(name="catalogo"),
            DetailScreen(name="detalle"), FavoritesScreen(name="favoritos"),
            PurchaseScreen(name="comprar"), ConnectionScreen(name="conexion"),
        ):
            manager.add_widget(screen)
        self.manager = manager
        Clock.schedule_once(lambda _dt: self.load_catalog(), .25)
        return manager

    @property
    def state_dir(self):
        path = Path(__file__).resolve().parent / ".mobile_state" if sys.platform == "win32" else Path(self.user_data_dir)
        path.mkdir(parents=True, exist_ok=True)
        return path

    def _load_local_state(self):
        try:
            data = json.loads((self.state_dir / "config.json").read_text(encoding="utf-8"))
            self.base_url = str(data.get("base_url") or self.base_url).rstrip("/")
        except (OSError, ValueError, TypeError):
            pass
        try:
            data = json.loads((self.state_dir / "favorites.json").read_text(encoding="utf-8"))
            self.favorites = {str(item) for item in data if item}
        except (OSError, ValueError, TypeError):
            self.favorites = set()

    def save_config(self):
        (self.state_dir / "config.json").write_text(json.dumps({"base_url": self.base_url}, indent=2), encoding="utf-8")

    def save_favorites(self):
        (self.state_dir / "favorites.json").write_text(json.dumps(sorted(self.favorites), indent=2), encoding="utf-8")

    def absolute_url(self, relative):
        if not relative:
            return ""
        return urljoin(self.base_url + "/", str(relative).lstrip("/"))

    def load_catalog(self, on_done=None):
        def success(_request, result):
            vehicles = result.get("vehiculos", []) if isinstance(result, dict) else []
            self.catalog = vehicles
            self.online = True
            self._refresh_visible()
            if on_done: on_done(True, f"Conectado: {len(vehicles)} vehículos cargados.")

        def failure(_request, _error):
            self.online = False
            self._refresh_visible()
            if on_done: on_done(False, "No se pudo conectar. Verifica IP, puerto y que la API esté iniciada.")

        UrlRequest(self.absolute_url("api/v1/catalogo"), on_success=success, on_error=failure, on_failure=failure, timeout=8)

    def _refresh_visible(self):
        screen = self.manager.current_screen
        if hasattr(screen, "set_status"):
            screen.set_status(self.online)
        if hasattr(screen, "render"):
            screen.render()

    def go(self, screen):
        if screen in self.manager.screen_names:
            self.manager.current = screen

    def open_vehicle(self, vehicle):
        self.selected_vehicle = vehicle
        self.go("detalle")

    def is_favorite(self, vehicle):
        return str(vehicle.get("codigo") or vehicle.get("id") or "") in self.favorites

    def toggle_favorite(self, vehicle):
        key = str(vehicle.get("codigo") or vehicle.get("id") or "")
        if not key:
            return
        if key in self.favorites:
            self.favorites.remove(key)
        else:
            self.favorites.add(key)
        self.save_favorites()


if __name__ == "__main__":
    GrupoJEMobileApp().run()
