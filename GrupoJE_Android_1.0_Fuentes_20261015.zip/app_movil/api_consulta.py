"""Puente HTTP de solo lectura para una futura app móvil de Grupo JE.

No crea ventas, no modifica inventario y no acepta operaciones de reserva.
Por defecto escucha únicamente en ``127.0.0.1``. Para exponerlo a una red
local se requiere un token explícito en ``GRUPO_JE_MOBILE_API_TOKEN``.
"""

from __future__ import annotations

import argparse
import json
import mimetypes
import os
import secrets
import socket
import sqlite3
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse


PROJECT_DIR = Path(__file__).resolve().parents[1]
SQLITE_PATH = PROJECT_DIR / "database" / "grupo_je.db"


def _connection() -> sqlite3.Connection:
    if not SQLITE_PATH.exists():
        raise FileNotFoundError("No se encontró la base de datos de Grupo JE.")
    connection = sqlite3.connect(f"{SQLITE_PATH.as_uri()}?mode=ro", uri=True)
    connection.row_factory = sqlite3.Row
    return connection


def catalogo() -> list[dict]:
    with _connection() as connection:
        rows = connection.execute(
            """
            SELECT v.id, v.codigo, v.marca, v.modelo, v.version, v.anio,
                   v.placa, v.tipo_vehiculo, v.kilometraje, v.transmision,
                   v.combustible, v.condicion, v.estado, v.descripcion,
                   v.descuento, p.precio_venta,
                   s.codigo_sucursal, s.nombre_sucursal,
                   COALESCE((SELECT f.ruta FROM vehiculo_fotos f
                              WHERE f.id_vehiculo = v.id
                              ORDER BY f.es_principal DESC, f.orden, f.id LIMIT 1),
                            v.foto_principal) AS foto_principal
              FROM vehiculos v
              LEFT JOIN productos p ON p.id = v.id_producto
              LEFT JOIN sucursales s ON s.id = v.id_sucursal
             ORDER BY CASE v.estado WHEN 'Disponible' THEN 0 WHEN 'Reservado' THEN 1 ELSE 2 END,
                      v.marca, v.modelo, v.anio DESC
            """
        ).fetchall()
        result = []
        for row in rows:
            vehicle = dict(row)
            vehicle["foto_url"] = f"/api/v1/fotos/{vehicle['id']}/0" if vehicle.get("foto_principal") else None
            result.append(vehicle)
        return result


def ventas() -> list[dict]:
    with _connection() as connection:
        rows = connection.execute(
            """
            SELECT v.id, v.numero_factura, v.cliente_nombre, v.tipo_pago,
                   v.total, v.fecha, v.estado, s.nombre_sucursal
              FROM ventas v
              LEFT JOIN sucursales s ON s.id = v.id_sucursal
             ORDER BY v.id DESC LIMIT 50
            """
        ).fetchall()
    return [dict(row) for row in rows]


def inventario() -> list[dict]:
    with _connection() as connection:
        rows = connection.execute(
            """
            SELECT codigo_producto, nombre, categoria, stock_actual,
                   stock_minimo, estado
              FROM productos
             WHERE estado = 'Activo'
             ORDER BY nombre LIMIT 100
            """
        ).fetchall()
    return [dict(row) for row in rows]


def reservas() -> list[dict]:
    with _connection() as connection:
        rows = connection.execute(
            """
            SELECT r.id, r.fecha_creacion, r.fecha_vencimiento, r.estado,
                   v.codigo AS codigo_vehiculo, v.marca, v.modelo, v.version,
                   v.anio, c.nombre AS cliente_nombre, c.apellido AS cliente_apellido,
                   s.codigo_sucursal, s.nombre_sucursal
              FROM reservas_vehiculos r
              LEFT JOIN vehiculos v ON v.id = r.id_vehiculo
              LEFT JOIN clientes c ON c.id = r.id_cliente
              LEFT JOIN sucursales s ON s.id = r.id_sucursal
             ORDER BY r.fecha_creacion DESC, r.id DESC LIMIT 50
            """
        ).fetchall()
    return [dict(row) for row in rows]


def sucursales() -> list[dict]:
    """Directorio público; no incluye gerente ni información interna."""
    with _connection() as connection:
        rows = connection.execute(
            """
            SELECT s.id, s.codigo_sucursal, s.nombre_sucursal, s.telefono,
                   s.direccion, s.departamento,
                   COUNT(CASE WHEN v.estado='Disponible' THEN 1 END) AS vehiculos_disponibles
              FROM sucursales s
              LEFT JOIN vehiculos v ON v.id_sucursal=s.id
             WHERE s.estado='Activo'
             GROUP BY s.id, s.codigo_sucursal, s.nombre_sucursal,
                      s.telefono, s.direccion, s.departamento
             ORDER BY s.nombre_sucursal
            """
        ).fetchall()
    return [dict(row) for row in rows]


def foto_vehiculo(vehicle_id: int, index: int) -> tuple[bytes, str] | None:
    if index < 0:
        return None
    with _connection() as connection:
        rows = connection.execute(
            """
            SELECT ruta FROM vehiculo_fotos
             WHERE id_vehiculo = ?
             ORDER BY es_principal DESC, orden, id
            """,
            (vehicle_id,),
        ).fetchall()
    if index >= len(rows):
        return None
    path = Path(str(rows[index]["ruta"] or ""))
    if not path.is_absolute():
        path = PROJECT_DIR / path
    try:
        path.resolve().relative_to(PROJECT_DIR.resolve())
    except (OSError, ValueError):
        return None
    if not path.is_file():
        return None
    return path.read_bytes(), mimetypes.guess_type(path.name)[0] or "application/octet-stream"


class ConsultaHandler(BaseHTTPRequestHandler):
    server_version = "GrupoJEMovilConsulta/1.0"

    def log_message(self, _format, *_args):
        """No escribe rutas, tokens ni parámetros de usuarios en consola."""

    def _authorized(self) -> bool:
        token = self.server.api_token  # type: ignore[attr-defined]
        if not token:
            return True
        value = self.headers.get("X-GrupoJE-Token", "")
        if not value:
            value = self.headers.get("Authorization", "").removeprefix("Bearer ").strip()
        return bool(value) and secrets.compare_digest(value, token)

    def _internal_allowed(self) -> bool:
        if self.server.public_only:  # type: ignore[attr-defined]
            return False
        return self._authorized()

    def _json(self, status: HTTPStatus, data: dict | list):
        body = json.dumps(data, ensure_ascii=False, default=str).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def _binary(self, payload: bytes, content_type: str):
        self.send_response(HTTPStatus.OK)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(payload)))
        self.send_header("Cache-Control", "private, max-age=300")
        self.end_headers()
        self.wfile.write(payload)

    def do_POST(self):
        self._json(HTTPStatus.METHOD_NOT_ALLOWED, {"error": "La API móvil es de solo lectura."})

    def do_PUT(self):
        self.do_POST()

    def do_DELETE(self):
        self.do_POST()

    def do_GET(self):
        path = urlparse(self.path).path.rstrip("/") or "/"
        try:
            if path == "/api/v1/health":
                self._json(HTTPStatus.OK, {"estado": "ok", "modo": "catalogo_publico" if self.server.public_only else "solo_lectura"})  # type: ignore[attr-defined]
            elif path == "/api/v1/catalogo":
                self._json(HTTPStatus.OK, {"vehiculos": catalogo()})
            elif path == "/api/v1/sucursales":
                self._json(HTTPStatus.OK, {"sucursales": sucursales()})
            elif path == "/api/v1/ventas":
                if not self._internal_allowed():
                    self._json(HTTPStatus.FORBIDDEN, {"error": "Recurso interno no disponible."})
                    return
                self._json(HTTPStatus.OK, {"ventas": ventas()})
            elif path == "/api/v1/inventario":
                if not self._internal_allowed():
                    self._json(HTTPStatus.FORBIDDEN, {"error": "Recurso interno no disponible."})
                    return
                self._json(HTTPStatus.OK, {"inventario": inventario()})
            elif path == "/api/v1/reservas":
                if not self._internal_allowed():
                    self._json(HTTPStatus.FORBIDDEN, {"error": "Recurso interno no disponible."})
                    return
                self._json(HTTPStatus.OK, {"reservas": reservas()})
            elif path.startswith("/api/v1/fotos/"):
                parts = path.split("/")
                if len(parts) != 6:
                    self._json(HTTPStatus.NOT_FOUND, {"error": "Fotografía no encontrada."})
                    return
                photo = foto_vehiculo(int(parts[4]), int(parts[5]))
                if photo is None:
                    self._json(HTTPStatus.NOT_FOUND, {"error": "Fotografía no disponible."})
                else:
                    self._binary(*photo)
            else:
                self._json(HTTPStatus.NOT_FOUND, {"error": "Recurso no encontrado."})
        except (OSError, sqlite3.Error, ValueError):
            self._json(HTTPStatus.SERVICE_UNAVAILABLE, {"error": "No fue posible consultar Grupo JE."})


def main() -> None:
    parser = argparse.ArgumentParser(description="API móvil de consulta para Grupo JE")
    parser.add_argument("--puerto", type=int, default=8765)
    parser.add_argument("--lan", action="store_true", help="Permite una red local solamente con token configurado.")
    parser.add_argument("--solo-publico", action="store_true", help="Expone únicamente catálogo, fotos, sucursales y estado; nunca datos internos.")
    args = parser.parse_args()
    token = os.environ.get("GRUPO_JE_MOBILE_API_TOKEN", "").strip()
    if args.lan and not token and not args.solo_publico:
        raise SystemExit("Para exponer la API en red local define GRUPO_JE_MOBILE_API_TOKEN.")
    host = "0.0.0.0" if args.lan else "127.0.0.1"
    server = ThreadingHTTPServer((host, args.puerto), ConsultaHandler)
    server.api_token = token  # type: ignore[attr-defined]
    server.public_only = bool(args.solo_publico)  # type: ignore[attr-defined]
    try:
        lan_ip = socket.gethostbyname(socket.gethostname())
    except OSError:
        lan_ip = "IP-DE-LA-PC"
    visible_host = lan_ip if args.lan else host
    mode = "catálogo público" if args.solo_publico else "solo lectura"
    print(f"API de Grupo JE en http://{visible_host}:{args.puerto} · {mode}")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
