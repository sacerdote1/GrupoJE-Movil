@echo off
setlocal
cd /d "%~dp0.."
echo Iniciando catalogo publico de Grupo JE para Android...
echo La PC y el telefono deben estar en la misma red.
py -3 app_movil\api_consulta.py --lan --solo-publico --puerto 8765
pause
