@echo off
setlocal
cd /d "%~dp0.."
set "KIVY_HOME=%CD%\.kivy_runtime"
py -3 app_movil\android\main.py
endlocal
